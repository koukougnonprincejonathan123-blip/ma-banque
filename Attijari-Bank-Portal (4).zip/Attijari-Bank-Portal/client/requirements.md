## Packages
framer-motion | Complex animations for transitions and success states
react-confetti | Celebration effect for successful transfers

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['"DM Sans"', "sans-serif"],
  display: ['"Outfit"', "sans-serif"],
}
